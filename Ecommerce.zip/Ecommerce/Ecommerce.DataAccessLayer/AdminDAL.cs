﻿using Ecommerce.Entity;
using EcommerceException;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Ecommerce.DataAccessLayer
{
    public class AdminDAL
    {
        public static List<Product> ProductList = new List<Product>();
        public static string fileName = "ProductList";
        public static bool AddProductDAL(Product newProduct)
        {
            bool productAdded = false;
            try
            {
                ProductList.Add(newProduct);
                productAdded = true;
                SetSerialization();

            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return productAdded;
        }

        public static Product SearchProductDAL(string searchProductName)
        {
            Product searchProduct = null;
            try
            {
                for (int i = 0; i < ProductList.Count; i++)
                {
                    Product product = ProductList[i];
                    if (product.Name == searchProductName)
                    {
                        searchProduct = ProductList[i];
                        break;
                    }
                }
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return searchProduct;
        }

        public static bool UpdateProductDAL(Product updateProduct)
        {
            bool productUpdated = false;
            try
            {


                for (int i = 0; i < ProductList.Count; i++)
                {
                    Product product = ProductList[i];
                    if (product.Name == updateProduct.Name)
                    {
                        ProductList[i] = updateProduct;
                        SetSerialization();
                        break;
                    }
                }

                productUpdated = true;
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return productUpdated;

        }


        public static void SetSerialization()
        {
            try
            {
                using (Stream file = File.Open(fileName, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, ProductList);
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("File not found.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }

    }
}
