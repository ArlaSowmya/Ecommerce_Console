﻿
using Ecommerce.Entity;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace Ecommerce.DataAccessLayer
{
    public class CustomerDAL
    {
        public static List<Customer> CustomerList = new List<Customer>();
        public static string fileName = "CustomerList";
        public static List<Product> Productlist = new List<Product>();
        public static string fileName1 = "Productlist";
        public static List<Customer> GetAllCustomerDAL()
        {
            return CustomerList;
        }
        public static bool AddProductCartDAL(Product newProduct)
        {
            bool productAdded = false;
            try
            {
                Productlist.Add(newProduct);
                productAdded = true;
                SetSerialization();

            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return productAdded;
        }
        public static List<Product> GetAllProductDAL()
        {
            return Productlist;
        }
        public static void SetSerialization()
        {
            try
            {
                using (Stream file = File.Open(fileName, FileMode.Create))
                {
                    BinaryFormatter bf = new BinaryFormatter();
                    bf.Serialize(file, CustomerList);
                    file.Close();
                }
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine("File not found.");
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }

        }
    }
}
