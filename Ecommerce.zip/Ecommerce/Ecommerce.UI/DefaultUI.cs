﻿using Ecommerce.Entity;
using EcommerceException;
using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Runtime.CompilerServices;

namespace Ecommerce.UI
{
    class Default1UI
    {
        static void Main(string[] args)
        {
            EcommerceBussinessLayer.AdminBL.setlist();

            int choice;
            do
            {
                PrintMenu();
                Console.WriteLine("Enter Choice :");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        Admin();
                        break;
                    case 2:
                        Customer();
                        break;
                    default:
                        //SetSerialization();
                        break;
                }
            } while ((choice > 0 && choice < 2));
        }

        private static void PrintMenu()
        {
            Console.WriteLine("\n***********Ecommerce System ***********");
            Console.WriteLine("1. Admin");
            Console.WriteLine("2. Customer");

        }
        private static void Admin()
        {
            int choice;
            do
            {
                PrintMenu1();
                Console.WriteLine("Enter Choice :");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        AddProducts();
                        break;
                    case 2:
                        ViewCustomers();
                        break;
                    case 3:
                        ManageOrders();
                        break;
                    default:
                        //SetSerialization();
                        break;
                }
            } while ((choice > 0 && choice < 3));
        }

        private static void PrintMenu1()
        {
            Console.WriteLine("\n***********Admin Roles***********");
            Console.WriteLine("1. Add Products");
            Console.WriteLine("2. View Customers");
            Console.WriteLine("3. Manage Orders");
        }
        private static void AddProducts()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("*******************************************************************************");
                Console.WriteLine("                                 Add product Details                           ");
                Console.WriteLine("********************************************************************************");
                Product newProduct = new Product();
                Console.WriteLine("Enter Product Name :");
                newProduct.Name = Console.ReadLine();
                Console.WriteLine("Enter Product Cost :");
                newProduct.Cost = Console.ReadLine();
                Console.WriteLine("Enter Product Quantity :");
                newProduct.Quantity = Console.ReadLine();
                bool ProductAdded = EcommerceBussinessLayer.AdminBL.AddProductBL(newProduct);
                if (ProductAdded)
                    Console.WriteLine("Product Added");
                else
                    Console.WriteLine("Product not Added");
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void ViewCustomers()
        {
            try
            {
                List<Customer> CustomerList = EcommerceBussinessLayer.CustomerBL.GetAllCustomerBL();
                if (CustomerList != null && CustomerList.Count > 0)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("CustomerName\t\tEmail\t\tPhoneNumber");
                    Console.WriteLine("******************************************************************************");
                    foreach (Customer Customer in CustomerList)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", Customer.CustomerName, Customer.Email, Customer.PhoneNo);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Customer Details Available");
                }
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void ManageOrders()
        {

            try
            {
                string updateProductName;
                Console.Clear();
                Console.WriteLine("*******************************************************************************");
                Console.WriteLine("                                 Update Product Details                       ");
                Console.WriteLine("******************************************************************************");
                Console.WriteLine("Enter Product Name to Update Details:");
                updateProductName = Console.ReadLine();
                Product updatedProduct = EcommerceBussinessLayer.AdminBL.SearchProductBL(updateProductName);
                if (updatedProduct != null)
                {
                    Console.WriteLine("Update Product Name :");
                    updatedProduct.Name = Console.ReadLine();
                    Console.WriteLine("Update Cost :");
                    updatedProduct.Cost = Console.ReadLine();
                    Console.WriteLine("Update Product Quantity");
                    updatedProduct.Quantity = Console.ReadLine();
                    bool UpdatedProduct = EcommerceBussinessLayer.AdminBL.UpdateProductBL(updatedProduct);

                    if (UpdatedProduct)
                        Console.WriteLine("Product Details Updated");
                    else
                        Console.WriteLine("Product Details not Updated ");

                }
                else
                {
                    Console.WriteLine("No Product Details Available");
                }
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }




        }
        private static void Customer()
        {
            int choice;
            do
            {
                PrintMenu2();
                Console.WriteLine("Enter Choice :");
                choice = Int32.Parse(Console.ReadLine());
                switch (choice)
                {
                    case 1:
                        SearchProducts();
                        break;
                    case 2:
                        AddProductsToCart();
                        break;
                    case 3:
                        DisplayProductsinCart();
                        break;
                    default:
                        //SetSerialization();
                        break;
                }
            } while ((choice > 0 && choice < 3));
        }

        private static void PrintMenu2()
        {
            Console.WriteLine("\n***********Customer Roles***********");
           Console.WriteLine("1. Add Products To Cart");
           Console.WriteLine("2. View Products");
        //    Console.WriteLine("3. Place Orders");
        
    }
        private static void SearchProducts()
        {
            try
            {
                string searchProductName;
                Console.WriteLine("Enter Name to Search:");
                searchProductName = Console.ReadLine();
                Product searchProduct = EcommerceBussinessLayer.AdminBL.SearchProductBL(searchProductName);
                if (searchProduct != null)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Name\t\tCost\t\tQuantity");
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("{0}\t\t{1}\t\t{2}", searchProduct.Name, searchProduct.Cost, searchProduct.Quantity);
                    Console.WriteLine("******************************************************************************");
                }
                else
                {
                    Console.WriteLine("No Product Details Available");
                }

            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
        private static void AddProductsToCart()
        {
            try
            {
                Console.Clear();
                Console.WriteLine("*******************************************************************************");
                Console.WriteLine("                                 Add product To Cart                           ");
                Console.WriteLine("********************************************************************************");
                Product newProduct = new Product();
                Console.WriteLine("Enter Product Name :");
                
                newProduct.Cost = Console.ReadLine();
                Console.WriteLine("Enter Product Quantity :");
                newProduct.Quantity = Console.ReadLine();
                bool ProductAdded = EcommerceBussinessLayer.CustomerBL.AddProductCartBL(newProduct);
                if (ProductAdded)
                    Console.WriteLine("Product Added");
                else
                    Console.WriteLine("Product not Added");
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        private static void DisplayProductsinCart()
        {
            try
            {
                List<Product> Productlist = EcommerceBussinessLayer.CustomerBL.GetAllProductBL();
                if (Productlist != null && Productlist.Count > 0)
                {
                    Console.WriteLine("******************************************************************************");
                    Console.WriteLine("Name\t\tCost\t\tQuantity");
                    Console.WriteLine("******************************************************************************");
                    foreach (Product Product in Productlist)
                    {
                        Console.WriteLine("{0}\t\t{1}\t\t{2}", Product.Name, Product.Cost, Product.Quantity);
                    }
                    Console.WriteLine("******************************************************************************");

                }
                else
                {
                    Console.WriteLine("No Product Details Available");
                }
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }
        }


                private static void SetSerialization()
        {
            EcommerceBussinessLayer.AdminBL.SetSerialization();
        }
    }


}
