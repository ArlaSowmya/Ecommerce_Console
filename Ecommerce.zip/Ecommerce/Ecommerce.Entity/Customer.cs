﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecommerce.Entity
{
     public class Customer
    {
        public string CustomerName { get; set; }

        public string Email { get; set; }

        public string PhoneNo { get; set; }
    }

   
}
