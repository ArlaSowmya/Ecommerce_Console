﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Ecommerce.Entity
{
    public class Product
    {
        public string Name { get; set; }
        public string Cost { get; set; }
        public string Quantity { get; set; }
    }

   
}
