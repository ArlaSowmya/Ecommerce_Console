﻿using System;

namespace Ecommerce.Entity
{
    public class Admin
    {
        public string AdminName { get; set; }

        public string Email { get; set; }

        public string PhoneNo { get; set; }

    }
}
