﻿using Ecommerce.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace EcommerceBussinessLayer
{
    public class CustomerBL
    {

        public static List<Customer> GetAllCustomerBL()
        {
            List<Customer> CustomerList = null;
            try
            {
                CustomerList = Ecommerce.DataAccessLayer.CustomerDAL.GetAllCustomerDAL();
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return CustomerList;
        }
        public static bool AddProductCartBL(Product newProduct)
        {
            bool productAdded = false;
            try
            {
                productAdded = Ecommerce.DataAccessLayer.CustomerDAL.AddProductCartDAL(newProduct);

            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }


            return productAdded;
        }
        public static List<Product> GetAllProductBL()
        {
            List<Product> Productlist = null;
            try
            {
                Productlist = Ecommerce.DataAccessLayer.CustomerDAL.GetAllProductDAL();
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return Productlist;
        }


    }
}
