﻿using Ecommerce.DataAccessLayer;
using Ecommerce.Entity;
using EcommerceException;
using System;

namespace EcommerceBussinessLayer
{
    public class AdminBL
    {
        public static bool AddProductBL(Product newProduct)
        {
            bool productAdded = false;
            try
            {
                productAdded = Ecommerce.DataAccessLayer.AdminDAL.AddProductDAL(newProduct);
                
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }
          

            return productAdded;
        }

        public static Product SearchProductBL(string searchProductName)
        {
            Product searchProduct = null;
            try
            {
                searchProduct = Ecommerce.DataAccessLayer.AdminDAL.SearchProductDAL(searchProductName);
            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }

            return searchProduct;

        }

        public static bool UpdateProductBL(Product updateProduct)
        {
            bool updatedProduct = false;
            try
            {

                Ecommerce.DataAccessLayer.AdminDAL ProductDAL = new Ecommerce.DataAccessLayer.AdminDAL();
                updatedProduct = Ecommerce.DataAccessLayer.AdminDAL.UpdateProductDAL(updateProduct);

            }
            catch (EcommerceException.Ecommerceexception ex)
            {
                Console.WriteLine(ex.Message);
            }


            
            return updatedProduct; ;
        }
public static bool UpdateProductBL(bool updatedProduct)
        {
            throw new NotImplementedException();
        }
    


        public static void setlist()
        {
            //throw new NotImplementedException();
        }
        public static void SetSerialization()
        {

            if (Ecommerce.DataAccessLayer.CustomerDAL.CustomerList != null)
            {
                Ecommerce.DataAccessLayer.CustomerDAL.SetSerialization();
            }
        }
    }
}
